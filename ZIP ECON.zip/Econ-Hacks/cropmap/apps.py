from django.apps import AppConfig


class CropmapConfig(AppConfig):
    name = 'cropmap'
