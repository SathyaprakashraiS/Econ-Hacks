from django.apps import AppConfig


class DeliverypersonConfig(AppConfig):
    name = 'deliveryperson'
